using System.Text.Json.Serialization;
using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Core.Attributes.Registration;
using CounterStrikeSharp.API.Modules.Admin;
using CounterStrikeSharp.API.Modules.Commands;
using CounterStrikeSharp.API.Modules.Timers;
using CounterStrikeSharp.API.Modules.Utils;
using Timer = CounterStrikeSharp.API.Modules.Timers.Timer;

namespace uf_autorespawn;

public class UFAutorespawnConfig : BasePluginConfig
{
    [JsonPropertyName("Enabled")] public bool Enabled { get; set; } = true;
    [JsonPropertyName("RespawnTime")] public float RespawnTime { get; set; } = 30.0f;
    [JsonPropertyName("RespawnDelay")] public float RespawnDelay { get; set; } = 0.5f;
    [JsonPropertyName("SpawnkillDetection")] public bool SpawnkillDetection { get; set; } = true;
}

public class UFAutorespawn : BasePlugin, IPluginConfig<UFAutorespawnConfig>
{
    public override string ModuleName => "uf-autorespawn";
    public override string ModuleVersion => "1.0.3";
    public override string ModuleAuthor => "monsterfacegames";
    public override string ModuleDescription => "Auto-respawn with spawnkill detection for MG-Course maps.";

    public UFAutorespawnConfig Config { get; set; } = new();

    private bool _canRespawn;
    private Timer? _respawnTimer;
    private readonly Dictionary<int, List<double>> _deathHistory = new();
    private bool _firstRound;

    public void OnConfigParsed(UFAutorespawnConfig config)
    {
        Config = config;
    }

    public override void Load(bool hotReload)
    {
        RegisterEventHandler<EventPlayerDeath>(OnPlayerDeath);
        RegisterEventHandler<EventRoundStart>(OnRoundStart);
        RegisterEventHandler<EventPlayerDisconnect>(OnPlayerDisconnect);
        RegisterListener<Listeners.OnMapStart>(OnMapStart);

        Server.PrintToConsole("[uf-autorespawn] loaded");
    }

    private void OnMapStart(string map)
    {
        Server.NextFrame(() =>
        {
            _deathHistory.Clear();
            _firstRound = false;
            _canRespawn = false;
            Server.PrintToConsole("[uf-autorespawn] map started");
        });
    }

    private HookResult OnRoundStart(EventRoundStart @event, GameEventInfo info)
    {
        try
        {
            _canRespawn = true;
            _respawnTimer?.Kill();
            _respawnTimer = null;

            if (!_firstRound)
            {
                _firstRound = true;
                Server.ExecuteCommand("mp_respawn_on_death_t 0");
                Server.ExecuteCommand("mp_respawn_on_death_ct 0");
                if (Config.RespawnTime > 0)
                    Server.ExecuteCommand("mp_ignore_round_win_conditions true");
            }

            if (Config.RespawnTime > 0)
            {
                float t = Config.RespawnTime;
                Chat("Spawnkill protection on for {0} seconds", t);
                _respawnTimer = AddTimer(t, () =>
                {
                    _canRespawn = false;
                    Chat("Respawn disabled after {0} seconds!", t);
                }, TimerFlags.STOP_ON_MAPCHANGE);
            }
        }
        catch (Exception ex)
        {
            Server.PrintToConsole($"[uf-autorespawn] roundstart error: {ex.Message}");
        }
        return HookResult.Continue;
    }

    private HookResult OnPlayerDeath(EventPlayerDeath @event, GameEventInfo info)
    {
        try
        {
            if (!Config.Enabled) return HookResult.Continue;

            var player = @event.Userid;
            if (player == null || !player.IsValid) return HookResult.Continue;
            int slot = player.Slot;
            if (slot < 0) return HookResult.Continue;

            if (_canRespawn && Config.SpawnkillDetection)
            {
                double now = (DateTime.UtcNow - DateTime.UnixEpoch).TotalSeconds;
                if (!_deathHistory.TryGetValue(slot, out var times))
                {
                    times = new List<double>();
                    _deathHistory[slot] = times;
                }
                times.Add(now);
                times.RemoveAll(t => now - t > 5.0);
                if (times.Count >= 2 && times[^1] - times[^2] < 1.0)
                {
                    _canRespawn = false;
                    Chat("Spawnkill detected, disabling respawn!");
                    Server.PrintToConsole($"[uf-autorespawn] DETECTED slot={slot} deaths={times.Count} diff={times[^1]-times[^2]:F3}s");
                    AddTimer(0.1f, CheckRoundEnd);
                    return HookResult.Continue;
                }
                Server.PrintToConsole($"[uf-autorespawn] no detect slot={slot} deaths={times.Count} last2diff={(times.Count>=2 ? (times[^1]-times[^2]).ToString("F3") : "N/A")}s");
            }

            if (_canRespawn)
            {
                CCSPlayerController? captured = player;
                float delay = Math.Max(Config.RespawnDelay, 0.1f);
                AddTimer(delay, () =>
                {
                    if (!_canRespawn) return;
                    RespawnPlayer(captured);
                }, TimerFlags.STOP_ON_MAPCHANGE);
            }

            AddTimer(0.1f, CheckRoundEnd);
        }
        catch (Exception ex)
        {
            Server.PrintToConsole($"[uf-autorespawn] death error: {ex.Message}");
        }
        return HookResult.Continue;
    }

    private HookResult OnPlayerDisconnect(EventPlayerDisconnect @event, GameEventInfo info)
    {
        try
        {
            var player = @event.Userid;
            if (player != null && player.IsValid)
            {
                int slot = player.Slot;
                if (slot >= 0) _deathHistory.Remove(slot);
            }
            AddTimer(1.0f, CheckRoundEnd);
        }
        catch (Exception ex)
        {
            Server.PrintToConsole($"[uf-autorespawn] disconnect error: {ex.Message}");
        }
        return HookResult.Continue;
    }

    private void RespawnPlayer(CCSPlayerController? player)
    {
        try
        {
            if (player == null || !player.IsValid || player.PawnIsAlive || !_canRespawn) return;
            player.Respawn();
            Chat("Respawned {0}", player.PlayerName);
        }
        catch (Exception ex)
        {
            Server.PrintToConsole($"[uf-autorespawn] respawn error: {ex.Message}");
        }
    }

    private void CheckRoundEnd()
    {
        try
        {
            if (_canRespawn) return;
            int alive = 0, playing = 0;
            foreach (var p in Utilities.GetPlayers())
            {
                if (p == null || !p.IsValid) continue;
                if (p.TeamNum != (byte)CsTeam.None && !p.IsBot) playing++;
                if (p.PawnIsAlive && !p.IsBot) alive++;
            }
            if (alive == 0 && playing > 0)
                Server.ExecuteCommand("mp_restartgame 1");
        }
        catch (Exception ex)
        {
            Server.PrintToConsole($"[uf-autorespawn] roundend error: {ex.Message}");
        }
    }

    private void Chat(string msg, params object[] args)
    {
        string text = string.Format(msg, args);
        Server.PrintToChatAll($" {ChatColors.Green}[uf-autorespawn]{ChatColors.Default} {text}");
    }

    [ConsoleCommand("css_autorespawn", "Check or toggle auto-respawn")]
    [RequiresPermissions("@css/cvar")]
    public void OnCommand(CCSPlayerController? player, CommandInfo cmd)
    {
        try
        {
            if (cmd.ArgCount == 1)
            {
                string s = _canRespawn ? "enabled" : "disabled";
                string m = $"Auto-respawn is {s}.";
                if (player != null && player.IsValid)
                    player.PrintToConsole($"[uf-autorespawn] {m}");
                else
                    Server.PrintToConsole($"[uf-autorespawn] {m}");
                return;
            }
            if (int.TryParse(cmd.GetArg(1), out int v))
            {
                _canRespawn = v != 0;
                Chat("Auto-respawn manually {0}", v != 0 ? "enabled" : "disabled");
            }
        }
        catch { }
    }
}
